import userController from './userController.js';


export default {
    userController
}