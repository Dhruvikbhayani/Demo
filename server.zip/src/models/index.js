import User from "./User.js";


export default {
    User

}